package testscripts.applicationcontext;

public class ScenarioContext {

    // These values should come from database
    public static String USER_EMAIL = "mastertest729@gmail.com";
    public static String ALREADY_REGISTERED_USER_EMAIL = "dhirajk04@gmail.com";
    public static String USER_PASS = "Qa@studydrive";
    public static String UNIVERSITY_NAME = "987654321";
    public static String SELECT_FIELD_OF_STUDY = "Engineering";
    public static String STUDY_PROGRAM = "Engineering";
    public static String STARTING_SEMESTER = "Winter 2020/21";
}
